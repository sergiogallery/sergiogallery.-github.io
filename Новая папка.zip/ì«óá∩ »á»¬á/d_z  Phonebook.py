
# from dataclasses import fields
# import linecache
# from tarfile import RECORDSIZE


# def show_menu():
#     print('\n1. Распечатать справочник'
#           '\n2. Найти телефон по фамилии'
#           '\n3. Изменить номер телефона'
#           '\n4. Удалить запись'
#           '\n5. Найти абонента по номеру телефона'
#           '\n6. Добавить абонента в справочник'
#           '\n7. Закончить работу')



# import linecache

# def read_txt(filename):
#     phone_book = []
#     fields = ['Фамилия', 'Имя', 'Телефон', 'Описание']

#     with open(filename, 'r') as file:
#         for line in file:
#             record = dict(zip(fields, line.strip().split(',')))
#             phone_book.append(record)

#     return phone_book

# def write_txt(filename, phone_book):
#     with open(filename, 'w') as file:
#         for record in phone_book:
#             file.write(','.join(record.values()) + '\n')

# # Example usage:
# filename = 'phonebook.txt'

# # Reading from the file
# phone_book = read_txt(filename)
# print(phone_book)

# # Modifying the phone book (add, delete, update)

# # Writing back to the file
# write_txt(filename, phone_book)


import shelve

class PhoneBook:
    def __init__(self, nameBook, dicRec={}):
        self.nameBook = nameBook
        self.dicRec = dicRec

    def loadBook(self):
        with shelve.open(self.nameBook) as db:
            self.dicRec = dict(db.items())

    def saveBook(self):
        with shelve.open(self.nameBook) as db:
            for key, record in self.dicRec.items():
                db[key] = record

    def createRec(self):
        print(self.nameBook)
        label = input('название записи: ')
        phone = input('телефон : ')
        print('ФИО,коммент. - Если нет, просто нажимайте Enter')
        familyName = input('ФИО: ')
        comment = input('Комментарий: ')

        if self.dicRec:
            keyRec = str(int(max(self.dicRec, key=int)) + 1)
        else:
            keyRec = "1"

        record = PhoneRec(keyRec, label, phone, familyName, comment)
        self.dicRec[keyRec] = record

    def delPhoneRec(self, key):
        if key in self.dicRec:
            del self.dicRec[key]
            print(f"Запись с ключом {key} удалена.")
        else:
            print(f"Запись с ключом {key} не найдена.")

    def readPhoneRec(self):
        for key in self.dicRec.keys():
            print("{:<3}- {:<25}- {:<20}- {:<30}- {:<30}".format(
                key, self.dicRec[key].label,
                self.dicRec[key].phone,
                self.dicRec[key].familyName,
                self.dicRec[key].comment))

class PhoneRec:
    def __init__(self, keyRec, label, phone, familyName, comment):
        self.keyRec = keyRec
        self.label = label
        self.phone = phone
        self.familyName = familyName
        self.comment = comment

if __name__ == '__main__':
    t1 = PhoneBook("Телефоны")
    t1.loadBook()
    t1.createRec()
    t1.readPhoneRec()

    # Deleting a record (for example, using key "1")
    key_to_delete = input("Введите ключ записи для удаления: ")
    t1.delPhoneRec(key_to_delete)

    t1.saveBook()

    # Строка необходима пока нет графического интерфейса, 
    # чтобы командное окно с информацией не закрывалось,
    # пока вы не нажмете Enter.
    input('ОКОНЧАНИЕ РАБОТЫ')


